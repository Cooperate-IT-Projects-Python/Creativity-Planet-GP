import { useState } from 'react';
import { useNavigate,Navigate } from 'react-router-dom';
import { useToasts } from 'react-toast-notifications';

import { useAuth } from '../hooks';
import styles from '../styles/login.module.css';

const Signup = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [signingUp, setSigningUp] = useState('');
  const { addToast } = useToasts();
  const auth = useAuth();
  const navigate = useNavigate();
  console.log(navigate);

  const handleAddPostClick = async () => {
    setAddingPost(true);
    // do some checks
    const postData = {
      "title": "ascscsc",
      "content": "scscscsc",
      "rate_number": 1,
      "tags": [
          "tage1",
          "tage2"
      ],
      "created_at": "2023-03-12T20:30:58Z",
      "main_Image": null,
      "user": 2
  }
     try {
      const response = await fetch('http://127.0.0.1:8000/community/posts/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      });
       const data = await response.json();
       if (response.ok) {
        setPost('');
        posts.addPostToState(data.post);
        addToast('Post created successfully', {
          appearance: 'success',
        });
      } else {
        addToast(data.message, {
          appearance: 'error',
        });
      }
    } catch (error) {
      addToast(error.message, {
          appearance: 'error',
      });
    }
     setAddingPost(false);
  };

  if(auth.user){
    return <Navigate to="/" />
  }

  return (
    <form className={styles.loginForm} onSubmit={handleFormSubmit}>
      <span className={styles.loginSignupHeader}> Signup</span>
      <div className={styles.field}>
        <input
          placeholder="Name"
          type="text"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoComplete="new-password"
        />
      </div>
      <div className={styles.field}>
        <input
          placeholder="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="new-password"
        />
      </div>
      <div className={styles.field}>
        <input
          placeholder="Confirm password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div className={styles.field}>
        <input
          placeholder="Password"
          type="password"
          required
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </div>
      <div className={styles.field}>
        <button disabled={signingUp}>
          {signingUp ? 'Signing up...' : 'Signup'}
        </button>
      </div>
    </form>
  );
};

export default Signup;
